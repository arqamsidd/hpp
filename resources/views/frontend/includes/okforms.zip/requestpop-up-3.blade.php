<style>
.overlay-bg-new-popup {
background: rgba(0, 0, 0, 0.8);
position: absolute;
top: 0;
left: 0;
right: 0;
bottom: 0;
width: 100%;
height: 100%;
z-index: 10;
display: none;
}
.popupform-main-new-popup-req .close-btn {
    right: -15px;
    top: 15px;
    width: 35px;
    height: 35px;
    background: transparent;
    border: 0;
    color: #fff;
    background: #cf0e0e;
    font-weight: 300;
}
.popup-main-box .pop-box-2-new-pop-req h3 {position: absolute;bottom: 8px;z-index: 1;text-align: center;color: #fff;text-align: center;left: 0;right: 0;}

.popup-main-box .pop-box-2-new-pop-req h3 span {display: block;color: #fff;font-size: 16px;background: #cf0e0e;margin-top: 20px;text-align: center;margin: 0 auto;display: table;margin-top: 22px;padding: 10px 20px;border-radius: 3px;}

.popup-main-box .pop-box-2-new-pop-req h3 span a {color: #fff;}
.pop-form-new-popp-req .submit-btn {
font-size: 18px;
width: 100%;
padding: 15px 0px;
background-color: #000000;
color: #fff;
cursor: pointer;
border-radius: 5px;
position: relative;
border: none;
margin-top: 15px;
width: 100%;
margin: 10px 0 0 0px !important;
font-weight: 700;
}
.close-btn {
    width: 45px;
    height: 45px;
    display: block;
    position: absolute;
    top: 18px;
    right: 0px;
    font-size: 18px;
    font-weight: 900;
    color: #fff;
    padding-top: 3px;
    text-align: center;
    border-radius: 50px;
    align-items: center;
    display: grid;
    z-index: 9;
}
.pop-box-2-new-pop-req img {
    /* box-shadow: 2px 2px 20px 9px #00000045; */
    position: relative;
    /* left: 17px; */
    z-index: 1;
    /* border-bottom: 6px solid #fff; */
width: 100%;border-radius: 0;height: 592px;top: -1px;}
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
.control-group input::placeholder {
    color: #9b7171;
}

.control-group textarea::placeholder {
    color: #9b7171;
}
.pop-form-new-popp-req .submit-btn {
font-size: 18px;
padding: 15px 0px;
background: #fb2224;
color: #fff;
cursor: pointer;
border-radius: 5px;
position: relative;
border: none;
margin-top: 15px;
width: 100%;
}
.popupform-main-new-popup-req.active {
    display: flex !important;
    justify-content: center;
    align-items: center;
}

.popupform-main-new-popup-req {position: fixed;background: #000c;top: 0;bottom: 0;left: 0;width: 100%;width: 100%;height: 100%;z-index: 9999;background-repeat: no-repeat;background-size: cover;}
.pop-form-new-popp-req.ta-center-new-pop {
    background: #fff;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    width: 400px;
    height: 588px;
    border-radius: 0 ;
    position: relative;
    top: 0;
    left: -11px;/* border-top: 10px solid #cf0e0e; */
background-image: -moz-linear-gradient( 140deg, rgb(217,213,250) 0%, rgb(255,255,255) 100%);
  background-image: -webkit-linear-gradient( 140deg, rgb(217,213,250) 0%, rgb(255,255,255) 100%);
  background-image: -ms-linear-gradient( 140deg, rgb(217,213,250) 0%, rgb(255,255,255) 100%);}

.pop-box-2-new-pop-req{

background:url('new-pop-bg-2.png');

}
.pop-box-2-new-pop-req span {
    color: #f9b400;
    font-size: 33px;
    font-weight: 600;
    position: relative;
    top: -11px;
}

.pop-box-2-new-pop-req h3 {
    color: #fff;
    font-size: 20px;
    line-height: 30px;
}
.pop-box-2-new-pop-req {
    /* background: transparent; */
    /* height: auto; */
    /* width: auto; */
    text-align: revert;
    /* padding: 0; */
    /* background-size: cover; */
    /* background-repeat: no-repeat; */
}
.pop-form-new-popp-req.ta-center-new-pop {
    padding: 25px 35px 25px 35px;
}

.pop-form-new-popp-req.ta-center-new-pop h3 {
    color: #2d2d2d;
    font-size: 17px;
    line-height: 25px;
    text-align: left;
    margin: 0;
}
.popupform-main-new-popup-req {
    align-items: center;
    justify-content: center;
}

.pop-form-new-popp-req.ta-center-new-pop h3 span {
    font-weight: bold;
}

.pop-form-new-popp-req.ta-center-new-pop h5 {
    color: #2d2d2d;
    font-size: 13px;
    font-weight: 500;
    text-transform: uppercase;
    line-height: 20px;
    text-align: left;
    padding: 20px 0 10px 0;
}
.pop-form-div-st input, .pop-form-div-st textarea {
    border-top: 0 !important;
    border-right: 0 !important;
    border-left: 0  !important;
    border-radius: 0 !important;
}

.pop-form-div-st label {
    color: #7d7f80;
    font-size: 13px;
    font-weight: 300;
}

div#pop-form-new-popp form {
    padding-top: 35px;
}

.pop-form-div-st label i {
    margin-right: 5px;
}

.pop-form-new-popp-req.ta-center-new-pop h5 a {
    color: #cf0e0e;
    font-weight: bold;
}
.pop-form-new-popp-req.ta-center-new-pop input {
    width: 100%;
    border-width: 0;
    
    border-style: solid;
    border-radius: 5px;
    background-color: #f3f3f3;
    height: auto;
    margin: 0 0 15px 0;
    padding: 16px 0 16px 28px;
}

.pop-form-new-popp-req.ta-center-new-pop select {
    border-width: 1px;
    border-color: rgb(207 14 14);
    border-style: solid;
    border-radius: 5px;
    background-color: rgb(207 14 14);
    height: auto;
    margin: 0 0 15px 0;
    outline: none;
    border-top: 0;
    border-right: 0;
    border-left: 0;
    color: #fff;
    font-size: 13px;
    font-weight: 300;
    padding:16px 0 16px 28px;

}

.pop-form-new-popp-req.ta-center-new-pop i {position: absolute;z-index: 1;top: 20px;left: 9px;}

.pop-form-new-popp-req.ta-center-new-pop .pop-form-div-st {position: relative;}




input {
    outline: none;
}
.popupform-main-new-popup-req #pop-form-new-popp {padding-left: 0;}

.pop-form-new-popp-req.ta-center-new-pop textarea {
    width: 100%;
    border-width: 1px;
    border-color: rgb(225, 225, 225);
    border-style: solid;
    border-radius: 5px;
    background-color: rgb(255, 255, 255);
    height: 80px;
    margin: 0 0 15px 0;
    padding: 16px 0 16px 28px;
    resize: none;
}

.pop-form-new-popp-req.ta-center-new-pop button {
    border-radius: 0;
    background-color: #000000;
    border: none;
    color: #fff;
    font-size: 18px;
    font-weight: 400;
    display: table;
    padding: 9px 42px;
    width: auto;
    display: table;
    text-align: center;
    width: 100%;
}

.pop-form-new-popp-req.ta-center-new-pop input::placeholder {
    color: #000;
}

.pop-form-new-popp-req.ta-center-new-pop textarea::placeholder {
    color: #000;
}
.pop-box-2-new-pop-req {
    position: relative;
    margin-right: 3px;
width: 396px;text-align: center;border-radius: 0;}

.pop-form-new-popp-req .close-btn{/* display: none; */}

.pop-form-new-popp-req.ta-center-new-pop h3 {
    margin: 0;
}
.popup-main-box {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.pop-box-2-new-pop-req h2 {
    position: absolute;
    bottom: 120px;
    z-index: 1;
    left: 0;
    right: 0;line-height: 35px;
    font-size: 39px;
    color: #fff;
    text-transform: uppercase;
text-align: center;}

.pop-box-2-new-pop-req h2 span {
    display: block;
    text-align: center;
    color: #fff;
    font-size: 28px;
    font-weight: 300;
}



@media (max-width:1600px) {
    .popup-main-box {
    transform: scale(0.9);
    }
}

@media (max-width:1366px) {
    .popup-main-box {
    transform: scale(0.8);
    }
}
@media (min-width:200px) and (max-width:767px) {
.pop-box-2-new-pop-req {
    display: none;
}
.pop-form-new-popp-req.ta-center-new-pop {
    /* background: url(auto-pop-bg-2-mob.png); */
    background-repeat: no-repeat;
    background-size: cover;
}

.pop-form-new-popp-req.ta-center-new-pop {
    width: 100%;
    height: auto;
    margin: 0px 10px;
    /* padding: 25px 0px; */
    border-radius: 0px;
}
.pop-form-new-popp-req .close-btn {
    /* display: block; */
    /* top: 5px; */
    /* right: 0px; */
    /* background: none; */
    /* border: none; */
    /* color: #ff9600; */
}
.pop-form-new-popp-req.ta-center-new-pop button {
    background: #cf0e0e;
}
.pop-form-new-popp-req.ta-center-new-pop h3 {
    margin: 0 0 5px 0;
}
.pop-form-new-popp-req.ta-center-new-pop h3 span {
    color: #fff;
}

.pop-form-new-popp-req.ta-center-new-pop h5 {
    /* color: #fff; */
}
}
</style>
<div class="overlay-bg-new-popup"></div>
<div  class="popupform-main-new-popup-req" style="display: none;">
    <div class="popup-main-box">
        <div class="pop-box-2-new-pop-req">
         <img src="/beta2/frontend/images/popup-img/auto-pop-bg-3.png">
         <h2><span>Get An</span> Instant Quote</h2>
         <h3>Try giving us a call at 
            <span><a href="tel: 866-225-2112"> 866-225-2112</a> or <a href="javascript:;" class="chats">Contact Support</a></span>
        </h3>
    </div> 

    <div class="pop-form-new-popp-req ta-center-new-pop">
          <a href="javascript:;" class="close-btn ta-center">X</a>  

        <h3>Fill out the form and we will get back <br>to you within 24 hours</h3>
        <div id="pop-form-new-popp" class="col-sm-12">
         
            <form method="POST" action="{{ url('requestpop-up-3') ; }}">
            @csrf
                <div class="pop-form-div-st pop-form-div-1">
                    <!-- <label><i class="fa fa-user" aria-hidden="true"></i> Enter name</label> -->
                   <i class="fa fa-user" aria-hidden="true"></i>
                   <input type="text" name="name"   required="" placeholder="Enter name">
                </div>
                <div class="pop-form-div-st pop-form-div-2">
                    <!-- <label><i class="fa fa-envelope" aria-hidden="true"></i> Enter Email</label> -->
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                    <input type="email" name="email"  required="" placeholder="Enter Email">
                </div>
                <div class="pop-form-div-st pop-form-div-3">
                    <!-- <label><i class="fa fa-phone" aria-hidden="true"></i> Enter Phone</label> -->
                    <i class="fa fa-phone" aria-hidden="true"></i>
                    <input type="number" name="phone"  required="" placeholder="Enter Number">
                </div>

                <div class="pop-form-div-st pop-form-div-3">
                    <!-- <label><i class="fa fa-phone" aria-hidden="true"></i> Enter Phone</label> -->
                    <input type="datetime-local" id="birthdaytime" name="birthdaytime" placeholder="Time & Date">
                </div>
                
                <div class="pop-form-div-st pop-form-div-4">
                    <!-- <label><i class="fa fa-comments" aria-hidden="true"></i> Discuss Your Project</label> -->
                    <i class="fa fa-comments" aria-hidden="true"></i><textarea name="description" placeholder="Message" required=""></textarea>
                </div>

                <button type="submit">Submit


               <input type="hidden" name="send" value="1" />
                        <input type="hidden" id="lead_area_popup" name="lead_area" value="for $19">
                            <input type="hidden" id="lead_org_price" name="lead_org_price" value="19">
                            <input type="hidden" name="send" value="1">
                            <input type="hidden" name="service_id" value="5730" class="service_id">
                            
                            <input type="hidden" name="lb_source" value="" />
                            <input type="hidden" name="lb_source_cat" value="" />
                            <input type="hidden" name="lb_source_nam" value="" />
                            <input type="hidden" name="lb_source_ema" value="" />
                            <input type="hidden" name="lb_source_con" value="" />
                            <input type="hidden" name="lb_source_pho" value="" />
                            <input type="hidden" name="lb_source_off" value="" />
                            
                            <input type="hidden" name="fullpageurl" value="" />
                            <input type="hidden" name="pageurl" value="" />
                            
                            <input type="hidden" name="ip2loc_ip" value="" />
                            <input type="hidden" name="ip2loc_isp" value="" />
                            <input type="hidden" name="ip2loc_org" value="" />
                            <input type="hidden" name="ip2loc_country" value="" />
                            <input type="hidden" name="ip2loc_region" value="" />
                           
                </button>

    
            </form>
        </div>
    </div>

</div>
</div>
</div>
<section class="footer-section">
   <div class="container">
      <div class="row">
         <div class="col-sm-5">
            <div class="footer-main wow fadeInLeft" data-wow-duration="1s">
               <h4>We Create What You Want</h4>
               <h2 style="font-size: 31px;">Get in Touch with Our Design Team for Free Consultation and Sample Kit</h2>
               <p>
Our creative team will provide you with all the tools, assistance, and support to ensure a pleasurable working experience. We offer Sample Kits that allow you to explore the possibilities and how you can use them to redefine and refine your business and attain a competitive edge.<br> 
You can fill out the form and order Free Sample if you need custom packaging requirements other than the standard available.</p>
            </div>
            <div class="footyer-logos wow fadeInLeft" data-wow-duration="1s">
               <img loading="lazy" src="{{asset('frontend')}}/images/footer-logos.png">
            </div>
         </div>
         <div class="col-sm-6 col-sm-offset-1 bnr-form-col wow zoomIn" >
            <form method="POST" action="{{ url('sample-kit-form') ; }}">
               @csrf
               <div class="form-div-box">
                  <div class="form-div-box">
                     <input name="name" required class="form-control" type="text"   placeholder="Enter Your Name" >
                  </div>
                   <div class="form-div-box">
                     <input name="companyname" required class="form-control" type="text"   placeholder="Company Name" >
                  </div>
                 <div class="form-div-box">
                     <input name="companywebsite" required class="form-control" type="text"   placeholder="Company Website" >
                  </div>
                    <div class="form-div-box">
                     <input name="socialaddress" required class="form-control" type="text"   placeholder="Social Media Address" >
                  </div>
                  
                  <div class="form-div-box">
                     <input name="email" required class="form-control" type="email"   placeholder="Email Address" >
                  </div>
                  <div class="form-div-box">
                     <input name="phone" required class="form-control" type="number"   placeholder="Phone Number" >
                  </div>
                  <!--<div class="form-div-box">-->
                  <!--   <textarea class="form-control san-bor" name="msg" placeholder="Message" required></textarea>-->
                  <!--</div>-->
                  <div class="form-div-box-new ">
                     
                     <!-- <input type="hidden" name="lead_area" value="">
                     <input type="hidden" name="lead_org_price" value="">
                     <input type="hidden" name="send" value="1"> -->
                     <!-- Email Source -->
                     <!-- <input type="hidden" name="lb_source"     value="" />
                     <input type="hidden" name="lb_source_cat"    value="" />
                     <input type="hidden" name="lb_source_nam"    value="" />
                     <input type="hidden" name="lb_source_ema"    value="" />
                     <input type="hidden" name="lb_source_con"    value="" />
                     <input type="hidden" name="lb_source_pho"    value="" />
                     <input type="hidden" name="lb_source_off"    value="" /> -->
                     <!-- Customer Info -->
                     <!-- <input type="hidden" name="fullpageurl"   value="" />
                     <input type="hidden" name="pageurl"       value="" /> -->
                     <!-- ip2Location -->
                     <input type="hidden" name="ip2loc_ip"     value="" />
                     <input type="hidden" name="ip2loc_isp"       value="" />
                     <input type="hidden" name="ip2loc_org"       value="" />
                     <input type="hidden" name="ip2loc_country"   value="" />
                     <input type="hidden" name="ip2loc_region"    value="" />
                     <input type="hidden" name="ip2loc_city"   value="" />
                     <input type="hidden" name="p_name" value="{{Request::segment(1)}}">
                     <button type="submit" class="btn custom-btn1">Submit Now </button>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>
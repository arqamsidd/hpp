         <div class="ftr-form-st ftr_form_st_mm">
            <form action="{{ url('custom-quote-form') ; }}" method="POST" enctype="multipart/form-data" class=""  >
               @csrf
               <div class="cat-bx-txt">
                  <h4>Get a Custom Quote</h4>
               </div>
               <div class="cat-form-2">
                  <ul class="nav" role="tablist">
                     <li role="presentation" class="active"><a href="#one" aria-controls="home" role="tab" data-toggle="tab">Step 1</a></li>
                     <li role="presentation"><a href="#two" aria-controls="profile" role="tab" data-toggle="tab">Step 2</a></li>
                  </ul>
                  <div class="tab-content">
                     <!-- Step 1 -->
                     <div role="tabpanel" class="tab-pane active" id="one">
                        <div class="row">
                           <div class="col-md-12 form-group">
                              <div class="breif-box1 breif-box5">
                                 <h4>Material</h4>
                                 <div class="row">
                                    <div class="col-sm-12">
                                       <span class="wpcf7-form-control-wrap material">
													<select name="material" class="wpcf7-form-control wpcf7-select intrested" aria-invalid="false">
														<!-- <option value="Standard white Corrugated Cardboard">Standard white Corrugated Cardboard</option> -->
														<option value="Please Select">Please Select</option>
														<option value="Corrugated Stock">Corrugated Stock</option>
														<option value="Foil Metalic Cardstock">Foil Metalic Cardstock</option>
														<option value="Kraft-ecofriendly / Brown Cardstock">Kraft Eco-friendly / Brown Cardstock</option>
														<option value="Rigid / Press Board Card">Rigid / Press Board Card</option>
														<option value="Textured / Linen / Neenah Cardstock" class="hideme">Textured / Linen / Neenah Cardstock</option>
														<option value="Colored Stock">Colored Stock</option>
														<option value="White Cardstock">White Cardstock</option>
														<option value="Holographic Stock">Holographic Stock</option>
													</select>
												</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-sm-3 form-group">
                              <div class="breif-box1 breif-box5 qty-inp">
                                 <h5>Length</h5>
                                 <div class="row">
                                    	<div class="col-sm-12">
											<span class="wpcf7-form-control-wrap length"><input type="number" name="length" value="1" class="wpcf7-form-control wpcf7-number wpcf7-validates-as-required wpcf7-validates-as-number input_product_des" aria-required="true" aria-invalid="false" placeholder=""></span>
										              </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-3 form-group">
                              <div class="breif-box1 breif-box5 qty-inp">
                                 <h5>Width</h5>
                                 <div class="row">
                                    <div class="col-sm-12">
										<span class="wpcf7-form-control-wrap width"><input type="number" name="width" value="1" class="wpcf7-form-control wpcf7-number wpcf7-validates-as-required wpcf7-validates-as-number input_product_des" aria-required="true" aria-invalid="false" placeholder=""></span>
									</div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-3 form-group">
                              <div class="breif-box1 breif-box5 qty-inp">
                                 <h5>Depth</h5>
                                 <div class="row">
                                    <div class="col-sm-12">
										<span class="wpcf7-form-control-wrap depth"><input type="number" name="depth" value="1" class="wpcf7-form-control wpcf7-number wpcf7-validates-as-required wpcf7-validates-as-number input_product_des" aria-required="true" aria-invalid="false" placeholder=""></span>
									</div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-3 form-group">
                              <div class="breif-box1 breif-box5 qty-inp">
                                 
                                 <div class="row">
                                    <div class="col-sm-12">
                                       <span class="wpcf7-form-control-wrap depth">
													<select name="unit" class="wpcf7-form-control wpcf7-select intrested inchcs line_removal" aria-invalid="false">
														<!--<option value="Unit">Unit</option>-->
														<option value="Inch">Inch</option>
														<option value="cm">cm</option>
														<option value="mm">mm</option>
													</select>
												</span>
                                       
                                       </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-4 form-nu-box form-group">
                             <div class="breif-box1 breif-box5 qty-inp quantity_field">
                              <h4>Quantity</h4>
                                 <div class="row">
                                       <div class="col-sm-12">
                                 <span class="wpcf7-form-control-wrap length"><input type="number" name="quantity" value="1" class="wpcf7-form-control wpcf7-number wpcf7-validates-as-required wpcf7-validates-as-number input_product_des" aria-required="true" aria-invalid="false" placeholder=""></span>
                                            </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-4 form-nu-box form-group">
                              <div class="breif-box1 breif-box5 qty-bx-brif">
                                 <h4>Printing</h4>
                                 	<div class="row">
												<div class="col-sm-12">
												<span class="wpcf7-form-control-wrap printing">
													
										<select name="printing" class="wpcf7-form-control wpcf7-select intrested" aria-invalid="false">
											<option value="Please Select">Please Select</option>
											<option value="Outside only">Outside only</option>
											<option value="inside only">inside only</option>
											<option value="both sides">Both Sides</option>
										</select>
												</span>
												</div>
											</div>
                              </div>
                           </div>
                           <div class="col-md-4 form-nu-box form-group">
                              <div class="breif-box1 breif-box5 qty-bx-brif">
                                 <h4>Card Thickness</h4>
                                 <div class="row">
												<div class="col-sm-12 mlk">
												<span class="wpcf7-form-control-wrap material">
													<select name="card_thickness" class="wpcf7-form-control wpcf7-select intrested" aria-invalid="false">
														<option value="Please Select">Please Select</option>
														<option value="11 pt (230 GSM) ">11 pt (230 GSM) </option>
														<option value="12 pt (250 GSM) ">12 pt (250 GSM) </option>
														<option value="13 pt (270 GSM) ">13 pt (270 GSM) </option>
														<option value="14pt (300 GSM)  ">14 pt (300 GSM)  </option>
														<option value="18 pt (350 GSM)" class="hded">18 pt (350 GSM)  </option>
														<option value="24 pt (460 GSM)" class="hded">24 pt (460 GSM)  </option>
													</select>
												</span>
												</div>
											</div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-sm-6 form-group">
                              <div class="breif-box1 breif-box5">
                                 <h4>Extra Finishes</h4>
                                 <div class="row">
												<div class="col-sm-12">
												<span class="wpcf7-form-control-wrap material">

													<select name="extra_finishes" class="wpcf7-form-control wpcf7-select intrested" aria-invalid="false">
														<option value="Please Select">Please Select</option>
														<option value="Debossing">Debossing</option>
														<option value="Embossing">Embossing </option>
														<option value="Foiling ">Foiling </option>
														<option value="Spot UV / Spot gloss ">Spot UV / Spot gloss </option>
														<option value="Raised Spot/UV">Raised Spot / UV</option>
                                                       	<option value="Holographic Foiling">Holographic Foiling</option>
													</select></span>
												</div>
											</div>
                              </div>
                           </div>
                           <div class="col-sm-6 form-group">
                              <div class="breif-box1 breif-box5">
                                 <h4>Coating / Lamination</h4>
                                <div class="row">
												<div class="col-sm-12">
												<span class="wpcf7-form-control-wrap material">

													<select name="coating_lamination" class="wpcf7-form-control wpcf7-select intrested" aria-invalid="false">
														<option value="Please Select">Please Select</option>
														<option value="Glossy lamination ">Glossy lamination </option>
														<option value="Matte lamination ">Matte lamination </option>
														<option value="Soft touch / Silk lamination">Soft touch / Silk lamination</option>
														<option value="Aqueous coating">Aqueous coating</option>
														<option value="Crystal UV / Liquid UV">Crystal UV / Liquid UV </option>

													</select></span>
												</div>
											</div>
                              </div>
                           </div>
                           <div class="col-sm-12 form-group">
                              <div class="breif-box1 breif-box5 breif_box_textaera">
                                 <h4>Description</h4>
                                 	<div class="row">
												<div class="col-sm-12">
												<span class="wpcf7-form-control-wrap printing">
													<div class="form-group">
										             <textarea type="text" name="description" class="form-control" required=""></textarea> 
									              </div>
												</span>
												</div>
											</div>
                              </div>
                           </div>
                           <div class="col-sm-12 form-group">
								    <label for="exampleFormControlFile1">Upload your Artwork  or Reference Image</label>
								    <input type="file" name="image" class="form-control-file" id="">
							</div>
                           <div class="col-sm-12">
                              <div class="chk-col-custom">
                                 <input type="button" value="Proceed" class="wpcf7-form-control wpcf7-submit btn btn-primary cat-form-btn-st" aria-controls="profile" role="tab" data-toggle="tab">
                                <!--  <input type="hidden" id="lead_area_popup" name="lead_area" value="for $19">
                                 <input type="hidden" id="lead_org_price" name="lead_org_price" value="19"> -->
                                 <!-- <input type="hidden" name="send" value="1"> -->
                                 <!-- <input type="hidden" name="service_id" value="5669" class="service_id"> -->
                                 
<!--                             <input type="hidden" name="lb_source" value="" />
                                 <input type="hidden" name="lb_source_cat" value="" />
                                 <input type="hidden" name="lb_source_nam" value="" />
                                 <input type="hidden" name="lb_source_ema" value="" />
                                 <input type="hidden" name="lb_source_con" value="" />
                                 <input type="hidden" name="lb_source_pho" value="" />
                                 <input type="hidden" name="lb_source_off" value="" /> -->
                                 
<!--                              <input type="hidden" name="fullpageurl" value="" />
                                 <input type="hidden" name="pageurl" value="" /> -->
                                 
                                 <input type="hidden" name="ip2loc_ip" value="" />
                                 <input type="hidden" name="ip2loc_isp" value="" />
                                 <input type="hidden" name="ip2loc_org" value="" />
                                 <input type="hidden" name="ip2loc_country" value="" />
                                 <input type="hidden" name="ip2loc_region" value="" />
                                 <input name="ip2loc_city" value="" type="hidden">
                                 <input type="hidden" name="p_name" value="{{Request::segment(1)}}">
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- Step 2 -->
                     <div role="tabpanel" class="tab-pane" id="two">
                        <div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<input type="text" name="name" class="form-control" placeholder="Full Name" required="">
										</div>
									</div>
								
									<div class="col-md-6 email-col-fm-bx-pd">
									<div class="form-group">
										<input type="email" name="email" class="form-control" placeholder="Email Address" required="">
									</div>
									</div>
								</div>
                        <div class="row">
                           <div class="col-md-12">
										<div class="form-group">
											<input type="tel" id="phone" name="phone" class="form-control" data-validation="Phone Number" placeholder="Phone" required="">
										</div>
									</div>
                          	<div class="col-sm-12">
										<div class="chk-col-custom">
											<h5>Using Professional Design Editor?</h5>
											<input type="submit" value="Order Now & Receive a Dieline Template" class="wpcf7-form-control wpcf7-submit btn btn-primary cat-form-btn-st">
											
										</div>
									</div>
                        </div>
                     </div>
                  </div>
                  
                  
               </div>
               <div class="wpcf7-response-output" aria-hidden="true"></div>
            </form>
            <div class="tuck-maon-box wow fadeInRight" >
               <div class="tuck-main">
                  <h3>Shipping:</h3>
                  <p>Free shipping for deliveries in the USA, UK, Canada, and Australia.</p>
               </div>
               <div class="tuck-main">
                  <h3>Payments:</h3>
                  <img src="{{asset('frontend')}}/images/payment-1.png">
               </div>
               <div class="tuck-main">
                  <h3>Guarantee:</h3>
                  <p>24/7 Customer Support, Fast Turnaround, Unique Design</p>
               </div>
            </div>
         </div>
 
 
 
 <script>
$(document).ready(function(){
  $(".tb").click(function(){
    $(".mlk").hide();
  });
  
});
</script>        
<script>
$(document).ready(function(){
  $(".hideme").click(function(){
    $(".hded").hide();
  });
  
});
$('#cardstock').change(
    function() {
        var carstock = $('#cardstock option:selected').val();
       if( carstock == 'cardo-opt'){
            $(".mlk").hide();
       }
       else if( carstock == 'Rigid Stock / pressboard stock'){
            $(".mlk").hide();
       }
       else if( carstock == 'textured / linen / Neenah cardstock'){
            $(".mlk").show();
            $(".hded").hide();
       }
       else{
            $(".mlk").show();
            $(".hded").show();
       }
    }
);
</script>
<!DOCTYPE html>
<html>
<head>
   <title></title>
</head>
<body>

   <p><strong>Box Type:</strong> {{$page_url}}</p>
   <p><strong>Unit:</strong> {{$unit}}</p>
   <p><strong>Description:</strong> {{$description}}</p>
   <p><strong>Name:</strong> {{$name}}</p>
   <p><strong>Email:</strong> {{$email}}</p>
   <p><strong>Phone:</strong> {{$phone}}</p>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
   <title></title>
</head>
<body>
   <p><strong>Name:</strong> {{$name}}</p>
   <p><strong>Email:</strong> {{$email}}</p>
   <p><strong>Phone:</strong> {{$phone}}</p>
<p><strong>Description:</strong> {{$description}}</p>
</body>
</html>
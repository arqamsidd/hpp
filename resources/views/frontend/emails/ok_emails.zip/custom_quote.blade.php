<!DOCTYPE html>
<html>
<head>
   <title></title>
</head>
<body>
   <p><strong>Material:</strong> {{$material}}</p>
   <p><strong>Length:</strong> {{$length}}</p>
   <p><strong>Width:</strong> {{$width}}</p>
   <p><strong>Depth:</strong> {{$depth}}</p>
   <p><strong>Unit:</strong> {{$unit}}</p>
   <p><strong>Quantity:</strong> {{$quantity}}</p>
   <p><strong>Printing:</strong> {{$printing}}</p>
   <p><strong>Card Thickness:</strong> {{$card_thickness}}</p>
   <p><strong>Extra Finishes:</strong> {{$extra_finishes}}</p>
   <p><strong>Coating Lamination:</strong> {{$coating_lamination}}</p>
   <p><strong>Description:</strong> {{$description}}</p>
   <p><strong>Name:</strong> {{$name}}</p>
   <p><strong>Email:</strong> {{$email}}</p>
   <p><strong>Phone:</strong> {{$phone}}</p>

</body>
</html>